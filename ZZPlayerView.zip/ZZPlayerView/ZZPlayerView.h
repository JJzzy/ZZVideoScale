//
//  ZZPlayerView.h
//
//  Created by ZZY on 19-2-3.
//  Copyright (c) 2019年. All rights reserved.
//

//视频播放控制类

#import <UIKit/UIKit.h>
#import "OpenGLView20.h"
#import "UVChannelInfoBean.h"
#import "UVPanGestureRecognizer.h"

#define ZOOM_MAX      10.0f  //数字放大最大倍数
#define ZOOM_MIN      1.0f   //数字放大最小倍数
#define ZOOM_EACHSIZE 0.05f  //数字放大倍数变化最小差值

@protocol ZZPlayerViewDelegate <NSObject>
//数字放大过程中，实时更新画面YUV数据
- (void)updateScreenYUVData;
@end

@interface ZZPlayerView : OpenGLView20

@property (nonatomic, weak) id<ZZPlayerViewDelegate>delegate;

//手势
@property (nonatomic, strong) UIPinchGestureRecognizer *pinch;
@property (nonatomic, strong) UVPanGestureRecognizer *panGesture;

//数字放大：倍数
@property (assign, nonatomic) CGFloat currentScale;//记录画面放大倍数
@property (assign, nonatomic) CGPoint glCenterPoint;//记录OpenGl纹理坐标中心点
@property (assign, nonatomic) CGPoint startPoint;//记录窗格上UIKit坐标点
@property (assign, nonatomic) CGFloat lastScale;//记录手势捏合过程中手势放大的倍数（用来判断当前是放大还是缩小）
@property (assign, nonatomic) NSUInteger lastFingerCount;//手指个数

//数字放大恢复
- (void)airResumeZoom;

@end

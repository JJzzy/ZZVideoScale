//
//  ZZPlayerView.m
//
//  Created by ZZY on 19-2-3.
//  Copyright (c) 2019年. All rights reserved.
//

#import "ZZPlayerView.h"
#import "UVEventConst.h"

@interface ZZPlayerView()<UIGestureRecognizerDelegate>

@end

@implementation ZZPlayerView {}

- (id)initWithCoder:(NSCoder*)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self addGestureRecognizer];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self addGestureRecognizer];
    }
    return self;
}

- (void)addGestureRecognizer {
    
    [self removeGestureRecognizer];

    //拖动手势，目前用于数字放大模块
    _panGesture = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(handlePanGesture:)];
    //捏合手势
    _pinch = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(handlePinchPress:)];
    
    _pinch.delegate = self;
    _panGesture.delegate = self;
    [self addGestureRecognizer:_pinch];
    [self addGestureRecognizer:_panGesture];
}

- (void)removeGestureRecognizer{
    [self removeGestureRecognizer:_pinch];
    [self removeGestureRecognizer:_panGesture];
    _pinch = nil;
    _panGesture = nil;
}

#pragma mark -- ZOOM_drag
//滑动手势--支持数字放大
- (void)handlePanGesture:(UIPanGestureRecognizer *)sender {
    if (_currentScale <= ZOOM_MIN) {
        return;
    }
    //开启数字放大状态
    switch (sender.state) {
        case UIGestureRecognizerStateBegan: {
            //获取初始位置
            _startPoint = [sender locationInView:self];
            break;
        }
        case UIGestureRecognizerStateChanged: {
            CGPoint movePoint = [sender locationInView:self];
            [self dragViewWithMovePoint:movePoint fingerCount:sender.numberOfTouches];
            break;
        }
        default:
            break;
    }
    if (_delegate) {
        [_delegate updateScreenYUVData];
    }
}

//缩放手势
- (void)handlePinchPress:(UIPinchGestureRecognizer *)sender
{
    UIPinchGestureRecognizer *Gsr = (UIPinchGestureRecognizer*)sender;
    
    //do other thing

    //数字放大功能:缩放
    [self setZoomScaleWithGesture:Gsr];
}

#pragma mark -- ZOOM_zoom
//数字放大功能
- (void)setZoomScaleWithGesture:(UIPinchGestureRecognizer *)gesture {
    static BOOL isZooming = NO;
    static int i = 0;
    CGFloat scale = 0;
    float viewWidth = self.frame.size.width;
    float viewHeight = self.frame.size.height;
    if([gesture state] == UIGestureRecognizerStateBegan) {
        isZooming = YES;
        //初始化中心点
        if (_currentScale <= ZOOM_MIN) {
            _glCenterPoint = CGPointMake(0.5f, 0.5f);
        }
    } else if ([gesture state] == UIGestureRecognizerStateChanged && isZooming) {
        CGPoint centerPoint = [gesture locationInView:self];
        scale = gesture.scale;
        if(_lastScale > scale){
            i = 0;
            _currentScale -= ZOOM_EACHSIZE;
        } else if (_lastScale < scale) {
            i = 0;
            _currentScale += ZOOM_EACHSIZE;
        } else {
            ++i;
            //缩放开始和结束时，存在3次左右scale不变的现象，为避免此时响应拖拽的方法导致画面飘动。在此增加判断，连续3次以上scale不变时，认为是用户进行拖动操作
            if (i > 3) {
                //缩放倍数未改变时，则响应拖动方法
                [self dragViewWithMovePoint:centerPoint fingerCount:gesture.numberOfTouches];
                _startPoint = centerPoint;//必须更新此坐标，否则无法正确计算位移
                return;
            }
        }
        //缩放倍数限制
        if (_currentScale > ZOOM_MAX) {
            _currentScale = ZOOM_MAX;
        } else if (_currentScale < ZOOM_MIN) {
            _currentScale = ZOOM_MIN;
        }
        //缩放过程中，实时更新校准画面中心点，防止画面位置飘移
        float dx = centerPoint.x - viewWidth/2;
        float dy = centerPoint.y - viewHeight/2;
        /*
         1、不同于单次缩放，二次缩放时，手指在屏幕上缩放的中心点变化会很大，为避免直接通过缩放中心坐标（即centerPoint），来计算渲染画面中心点（glCenterPoint）导致的误差，即会出现画面跳动的问题，因此采用增量更新的方式来计算渲染中心点（glCenterPoint）
         2、即每次缩放时，使用中心点的偏移量，加上上次渲染中心点的坐标，得出最新渲染中心点的坐标
         3、原理：窗格上A点为缩放点（在渲染画面中坐标为A1），B点为窗格中心点（即渲染画面显示的中心点B1）。缩放后，保持A点不变，B点在渲染画面图层中的映射坐标为B2点，（B2-B1）即为单次缩放的增量
         */
        float dxGlx = dx*ZOOM_EACHSIZE / (_currentScale*(_currentScale - ZOOM_EACHSIZE)*viewWidth);//X方向偏移量（放大时）
        float dxGly = dy*ZOOM_EACHSIZE / (_currentScale*(_currentScale - ZOOM_EACHSIZE)*viewHeight);//Y方向偏移量（放大时）
        if (_lastScale > scale) {//缩小时，增量取负
            dxGlx = -dxGlx;
            dxGly = -dxGly;
        }
        _lastScale = _currentScale == ZOOM_MIN ? 1.0 : scale;//数字放大为一倍时，继续缩小手势时，会产生局部放大。为避免此问题：在放大为一倍时，将手势默认缩放比例设置为1.0
        centerPoint.x = dxGlx + _glCenterPoint.x;
        centerPoint.y = (- dxGly + _glCenterPoint.y);
        _glCenterPoint = [self updateEdgeGlPoint:centerPoint withMovePoint:centerPoint];
        //渲染画面
        [self scaleWithScaleRatio:_currentScale x:_glCenterPoint.x y:_glCenterPoint.y];
        UVDLog(@"ZZY:GL_centerPoint x:%f y:%f  scale:%f", _glCenterPoint.x, _glCenterPoint.y, _currentScale);
    } else if ([gesture state] == UIGestureRecognizerStateEnded) {
        isZooming = NO;
    }
    if (_delegate) {
        [_delegate updateScreenYUVData];
    }
}

#pragma mark -- ZOOM_drag_glCenterPoint
//根据手势移动坐标计算渲染画面中心坐标
- (void)dragViewWithMovePoint:(CGPoint)movePoint fingerCount:(NSUInteger)fingerCount {
    static int j = 0;
    float dx = movePoint.x - _startPoint.x;
    float dy = movePoint.y - _startPoint.y;
    float viewWidth = self.frame.size.width;
    float viewHeight = self.frame.size.height;
    //将UIKit下手势偏移量（dx,dy），转化成OpenGl坐标系下，画面中心点偏移量（glx,gly）
    float glx = dx/(viewWidth*_currentScale);
    float gly = dy/(viewHeight*_currentScale);
    //以下方法为解决：多个手指点击窗格进行拖动后，手指离开界面时画面位置会出现偏移的问题（共两步解决方法）
    //1）经过测试，10倍下画面在进行拖动时，每次的偏移量都在 0.02 内；而多个手指离开界面时，不同手指间的位移偏差导致的偏移量都会大于 0.02（若小于0.02，则不会给视觉带来明显的偏差）。因此，在不同的倍数下，保证快速拖动时画面的流畅性，对偏移量做以下处理，偏移量大于 0.2/_currentScale 时，认为是多个手指离开界面，直接return。
    if ((glx >= 0.2/_currentScale || glx <= -0.2/_currentScale) || (gly >= 0.2/_currentScale || gly <= -0.2/_currentScale)) {
        _startPoint = movePoint;
        return;
    }
    //2）增加／减少手指数量是，大概会响应10次左右方法，此时产生的movePoint是不准确的，会导致画面偏移。而手势回调每秒执行60次左右，为保证视觉效果，在手指数量变动时的前20次回调不响应
    if (_lastFingerCount != fingerCount) {
        ++j;
        if (j < 20) {
            return;
        }
        _lastFingerCount = fingerCount;
        j = 0;
    }
    //计算画面中心点
    CGPoint cp = CGPointMake(_glCenterPoint.x - glx,  _glCenterPoint.y + gly);
    //1、更新位置，保持拖动的连续性；2、计算边缘数据，防止越界
    _glCenterPoint =  [self updateEdgeGlPoint:cp withMovePoint:movePoint];
    //渲染画面数据纹理
    [self scaleWithScaleRatio:_currentScale x:_glCenterPoint.x y:_glCenterPoint.y];
}

#pragma mark -- ZOOM_updateEdgePoint
//数字放大：计算更新边缘数据，防止越界
- (CGPoint)updateEdgeGlPoint:(CGPoint)glPoint withMovePoint:(CGPoint)movePoint {
    float viewWidth = self.frame.size.width;
    float viewHeight = self.frame.size.height;
    //左边缘
    float leftX = (viewWidth/2) / (_currentScale*viewWidth);
    //右边缘
    float rightX = 1.0f - (viewWidth/2) / (_currentScale*viewWidth);
    //上边缘
    float topY = (1.0f - (viewHeight/2)/(_currentScale*viewHeight));
    //下边缘
    float bottomY = (viewHeight/2)/(_currentScale*viewHeight);
    if (glPoint.x < leftX) {//左
        glPoint.x = leftX;
    } else if (glPoint.x > rightX) {//右
        glPoint.x = rightX;
    } else {
        //未拖动到边缘时，更新坐标，保证坐标的真实性
        _startPoint.x = movePoint.x;
    }
    if (glPoint.y < bottomY) {//下
        glPoint.y = bottomY;
    } else if (glPoint.y > topY) {//上
        glPoint.y = topY;
    } else {
        //未拖动到边缘时，更新坐标，保证坐标的真实性
        _startPoint.y = movePoint.y;
    }
    //更新绑定的缩放数据
    /*
     = _currentScale;
     = glPoint;
     */
    return glPoint;
}

//恢复数字放大状态为1.0倍
- (void)airResumeZoom {
    _currentScale = ZOOM_MIN;
    _lastScale = 1.0f;
    _glCenterPoint = CGPointMake(0.5f, 0.5f);
    _startPoint = CGPointMake(self.frame.size.width/2, self.frame.size.height/2);
    //需要保存_currentScale,_glCenterPoint
    [self scaleWithScaleRatio:_currentScale x:_glCenterPoint.x y:_glCenterPoint.y];
    UVILog(@"ZZY:resume zoom back");
}
/***************************************** 分割线  这里是处理手势冲突的一些核心代码，若无冲突，则不用在意 **************************************************/
#pragma mark -- Gesture_Conflict
//处理同时触发多个手势的问题（处理拖动画面、左滑返回手势）
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    //处理拖动、左滑返回手势
    if (otherGestureRecognizer != _panGesture) {
        return NO;
    }
    //处理UICollectionViewCell和Pan手势冲突的问题
    float viewWidth = self.frame.size.width;
    //左边缘
    float leftX = (viewWidth/2) / (_currentScale*viewWidth);
    //右边缘
    float rightX = 1.0f - (viewWidth/2) / (_currentScale*viewWidth);
    // 获取平移方向
    CGPoint translation = [(UIPanGestureRecognizer *)otherGestureRecognizer translationInView:otherGestureRecognizer.view];
    /*
     计算滑动角度比例：
     1、当滑动比例X：Y大于0.5时，响应collectionview滑页操作，取消拖动手势响应
     2、当滑动比例X：Y小于0.5时，直接响应拖动手势
     */
    float proportion = fabs(translation.x/translation.y);
    UVILog(@"ZZY:proportion :%f x :%f y :%f", proportion, translation.x, translation.y);
    if (proportion <= 0.5f) {
        return NO;
    }
    if (translation.x >= 0 && (_glCenterPoint.x <= leftX)) {
        // 向右滑动 && 画面滑动到最左侧
        [self cancelOtherGestureRecognizer:otherGestureRecognizer];
    } else if (translation.x <= 0 && (_glCenterPoint.x >= rightX)) {
        // 向左滑动 && 画面滑动到最右侧
        [self cancelOtherGestureRecognizer:otherGestureRecognizer];
    }
    return NO;
}
//取消响应事件
- (void)cancelOtherGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    NSSet *touchs = [_panGesture.event touchesForGestureRecognizer:otherGestureRecognizer];
    [otherGestureRecognizer touchesCancelled:touchs withEvent:_panGesture.event];
}


@end
